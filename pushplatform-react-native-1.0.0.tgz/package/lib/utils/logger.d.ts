/**
 * @pushplatform/react-native
 *
 * Utility functions for logging and validation
 */
/**
 * Logger utility (controlled by debug mode)
 */
export declare class Logger {
    private static debugEnabled;
    /**
     * Enable debug logging
     */
    static enable(): void;
    /**
     * Disable debug logging
     */
    static disable(): void;
    /**
     * Log debug message
     */
    static debug(message: string, ...args: unknown[]): void;
    /**
     * Log info message
     */
    static info(message: string, ...args: unknown[]): void;
    /**
     * Log warning message (always shown)
     */
    static warn(message: string, ...args: unknown[]): void;
    /**
     * Log error message (always shown)
     */
    static error(message: string, ...args: unknown[]): void;
}
//# sourceMappingURL=logger.d.ts.map