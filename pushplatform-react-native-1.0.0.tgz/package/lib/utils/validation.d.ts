/**
 * @pushplatform/react-native
 *
 * Input validation utilities
 */
import type { PushPlatformConfig, JSONObject } from '../types';
/**
 * Validate configuration object
 */
export declare function validateConfig(config: PushPlatformConfig): void;
/**
 * Validate user ID
 */
export declare function validateUserId(userId: unknown): void;
/**
 * Validate URL
 */
export declare function validateURL(url: unknown): void;
/**
 * Validate user data object
 */
export declare function validateUserData(userData: JSONObject | undefined): void;
/**
 * Legacy Validator class for backward compatibility
 */
export declare class Validator {
    static validateConfig: typeof validateConfig;
    static validateUserId: typeof validateUserId;
    static validateUserData: typeof validateUserData;
}
//# sourceMappingURL=validation.d.ts.map