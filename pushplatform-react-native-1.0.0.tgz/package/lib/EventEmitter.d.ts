/**
 * @pushplatform/react-native
 *
 * Event emitter wrapper for native events
 */
import type { NotificationContext, Subscription } from './types';
/**
 * Event names
 */
export declare const EventNames: {
    readonly REGISTRATION_UPDATED: "onRegistrationUpdated";
    readonly NOTIFICATION_RECEIVED: "onNotificationReceived";
    readonly NOTIFICATION_OPENED: "onNotificationOpened";
};
/**
 * Event emitter wrapper with type-safe listeners
 */
export declare class EventEmitter {
    /**
     * Add listener for registration updated event
     *
     * Fired when push token registration completes successfully.
     * Note: Token value is NOT passed to JavaScript (security).
     */
    static onRegistrationUpdated(callback: () => void): Subscription;
    /**
     * Add listener for notification received event
     *
     * Fired when push notification is received (foreground or background).
     */
    static onNotificationReceived(callback: (context: NotificationContext) => void): Subscription;
    /**
     * Add listener for notification opened event
     *
     * Fired when user taps on notification (app was terminated or backgrounded).
     */
    static onNotificationOpened(callback: (context: NotificationContext) => void): Subscription;
    /**
     * Remove all listeners
     */
    static removeAllListeners(): void;
}
//# sourceMappingURL=EventEmitter.d.ts.map