/**
 * @pushplatform/react-native
 *
 * Main PushPlatform SDK class
 */
import type { PushPlatformConfig, PermissionStatus, Subscription, NotificationContext, JSONObject } from './types';
/**
 * Push Platform SDK
 *
 * Main entry point for React Native SDK.
 * Wraps native iOS (Swift) and Android (Kotlin) SDKs.
 *
 * **Requirements:**
 * - React Native >= 0.77
 * - New Architecture (TurboModules) enabled
 * - iOS 13.0+
 * - Android API 21+
 */
export declare class PushPlatform {
    private static _instance;
    private static initialized;
    /**
     * Initialize the SDK
     *
     * Must be called once before using any other SDK methods.
     * Delegates to native SDK for actual initialization.
     *
     * @param config - SDK configuration
     * @throws {SDKError} If configuration is invalid or initialization fails
     *
     * @example
     * ```typescript
     * await PushPlatform.initialize({
     *   apiKey: 'your-api-key',
     *   environment: 'production',
     *   debug: false,
     * });
     * ```
     */
    static initialize(config: PushPlatformConfig): Promise<void>;
    /**
     * Get installation ID
     *
     * Returns the unique installation ID (UUID v4).
     * Installation ID is stable across app sessions and survives app reinstalls.
     *
     * @returns Installation ID
     * @throws {SDKError} If SDK not initialized
     *
     * @example
     * ```typescript
     * const installationId = await PushPlatform.getInstallationId();
     * console.log('Installation ID:', installationId);
     * ```
     */
    static getInstallationId(): Promise<string>;
    /**
     * Login user
     *
     * Associates this installation with a user ID.
     * Enables user-targeted push notifications.
     *
     * @param userId - User identifier (max 255 chars)
     * @param userData - Optional user metadata (JSON object)
     * @throws {SDKError} If SDK not initialized or validation fails
     *
     * @example
     * ```typescript
     * await PushPlatform.login('user-123', {
     *   name: 'John Doe',
     *   email: 'john@example.com',
     * });
     * ```
     */
    static login(userId: string, userData?: JSONObject): Promise<void>;
    /**
     * Logout user
     *
     * Dissociates this installation from the current user.
     * Installation remains active and can receive broadcast notifications.
     *
     * @throws {SDKError} If SDK not initialized
     *
     * @example
     * ```typescript
     * await PushPlatform.logout();
     * ```
     */
    static logout(): Promise<void>;
    /**
     * Request push notification permissions
     *
     * iOS: Always prompts for permissions.
     * Android: Required for API 33+ (Android 13+), no-op for older versions.
     *
     * @returns true if permission granted, false otherwise
     * @throws {SDKError} If SDK not initialized
     *
     * @example
     * ```typescript
     * const granted = await PushPlatform.requestPermissions();
     * if (granted) {
     *   console.log('Push notifications enabled');
     * } else {
     *   console.log('Push notifications denied');
     * }
     * ```
     */
    static requestPermissions(): Promise<boolean>;
    /**
     * Get current permission status
     *
     * @returns Permission status: 'granted', 'denied', or 'not-determined'
     * @throws {SDKError} If SDK not initialized
     *
     * @example
     * ```typescript
     * const status = await PushPlatform.getPermissionStatus();
     * if (status === 'not-determined') {
     *   await PushPlatform.requestPermissions();
     * }
     * ```
     */
    static getPermissionStatus(): Promise<PermissionStatus>;
    /**
     * Add listener for registration updated event
     *
     * Fired when push token registration completes successfully.
     * Note: Token value is NOT exposed to JavaScript (security).
     *
     * @param callback - Callback function (no parameters)
     * @returns Subscription handle to remove listener
     *
     * @example
     * ```typescript
     * const subscription = PushPlatform.onRegistrationUpdated(() => {
     *   console.log('Push registration updated');
     * });
     *
     * // Later: remove listener
     * subscription.remove();
     * ```
     */
    static onRegistrationUpdated(callback: () => void): Subscription;
    /**
     * Add listener for notification received event
     *
     * Fired when notification is received while app is running
     * (foreground or background).
     *
     * @param callback - Callback function with notification context
     * @returns Subscription handle to remove listener
     *
     * @example
     * ```typescript
     * const subscription = PushPlatform.onNotificationReceived((context) => {
     *   console.log('Notification received:', context.notification);
     *   if (context.isForegrounded) {
     *     // Handle foreground notification (show custom UI)
     *   }
     * });
     * ```
     */
    static onNotificationReceived(callback: (context: NotificationContext) => void): Subscription;
    /**
     * Add listener for notification opened event
     *
     * Fired when user taps on notification (app was terminated or backgrounded).
     *
     * @param callback - Callback function with notification context
     * @returns Subscription handle to remove listener
     *
     * @example
     * ```typescript
     * const subscription = PushPlatform.onNotificationOpened((context) => {
     *   console.log('Notification opened:', context.notification);
     *   // Navigate to specific screen based on notification data
     *   const deepLink = context.notification.data.deeplink;
     *   if (deepLink) {
     *     navigation.navigate(deepLink);
     *   }
     * });
     * ```
     */
    static onNotificationOpened(callback: (context: NotificationContext) => void): Subscription;
    /**
     * Remove all event listeners
     *
     * Clears all registered event listeners.
     * Useful for cleanup when component unmounts.
     *
     * @example
     * ```typescript
     * useEffect(() => {
     *   const sub1 = PushPlatform.onNotificationReceived(handler);
     *   const sub2 = PushPlatform.onNotificationOpened(handler);
     *
     *   return () => {
     *     sub1.remove();
     *     sub2.remove();
     *     // Or remove all at once:
     *     // PushPlatform.removeAllListeners();
     *   };
     * }, []);
     * ```
     */
    static removeAllListeners(): void;
    /**
     * Ensure SDK is initialized
     * @private
     */
    private static ensureInitialized;
}
//# sourceMappingURL=PushPlatform.d.ts.map