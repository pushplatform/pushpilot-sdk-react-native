/**
 * @pushplatform/react-native
 *
 * Main entry point for Push Platform React Native SDK
 */
export type { JSONPrimitive, JSONValue, JSONObject, JSONArray, PushPlatformConfig, Installation, PushNotification, NotificationContext, PermissionStatus, Subscription, } from './types';
export { SDKError, ErrorCode } from './types';
export { PushPlatform } from './PushPlatform';
export { PushPlatform as default } from './PushPlatform';
//# sourceMappingURL=index.d.ts.map