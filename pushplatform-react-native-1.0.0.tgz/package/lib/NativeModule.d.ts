/**
 * @pushplatform/react-native
 *
 * Native module interface for type-safe bridge to native iOS/Android SDKs
 */
import { NativeEventEmitter } from 'react-native';
import type { JSONObject } from './types';
/**
 * Native module interface (type-safe bridge)
 */
export interface PushPlatformNativeModule {
    /**
     * Initialize the SDK with configuration
     */
    initialize(config: {
        apiKey: string;
        environment: string;
        debug?: boolean;
        baseURL?: string;
    }): Promise<void>;
    /**
     * Get installation ID
     */
    getInstallationId(): Promise<string>;
    /**
     * Login user
     */
    login(userId: string, userData?: JSONObject): Promise<void>;
    /**
     * Logout user
     */
    logout(): Promise<void>;
    /**
     * Request push permissions (Android 13+ / iOS)
     */
    requestPermissions(): Promise<boolean>;
    /**
     * Get current permission status
     */
    getPermissionStatus(): Promise<string>;
}
/**
 * Typed native module
 */
export declare const NativeModule: PushPlatformNativeModule;
/**
 * Native event emitter instance
 */
export declare const NativeEvents: NativeEventEmitter;
//# sourceMappingURL=NativeModule.d.ts.map